#!/usr/bin/env python3
"""Validate takeoff.json before building in Tekla.

Usage:
    python validate_takeoff.py takeoff.json [--catalog catalog.json] [--min-confidence 0.8]

catalog.json (built from tekla_list_catalog results):
    {"profile": [...], "material": [...], "rebar": ["SD40 16", ...], "bolt": [...]}

Exit code 0 = no errors (warnings may remain), 1 = errors.
"""
import argparse
import json
import math
import re
import sys
from collections import Counter

TYPES = {"column", "beam", "plate", "rebar", "bolts", "weld", "assembly"}
PARAMETRIC = re.compile(r"^(PL\d+(\.\d+)?|\d+(\.\d+)?\*\d+(\.\d+)?|D\d+(\.\d+)?)$", re.I)


def is_point(p):
    return isinstance(p, list) and len(p) == 3 and all(isinstance(v, (int, float)) for v in p)


def dist(a, b):
    return math.sqrt(sum((x - y) ** 2 for x, y in zip(a, b)))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("takeoff")
    ap.add_argument("--catalog")
    ap.add_argument("--min-confidence", type=float, default=0.8)
    a = ap.parse_args()

    with open(a.takeoff, encoding="utf-8") as f:
        t = json.load(f)
    cat = None
    if a.catalog:
        with open(a.catalog, encoding="utf-8") as f:
            cat = {k: {str(v).upper() for v in vals} for k, vals in json.load(f).items()}

    errors, warnings = [], []
    E = lambda oid, msg: errors.append(f"[{oid}] {msg}")
    W = lambda oid, msg: warnings.append(f"[{oid}] {msg}")

    for key in ("grid", "levels", "objects"):
        if key not in t:
            E("file", f"missing '{key}'")
    objs = t.get("objects", [])
    ids = Counter(o.get("id") for o in objs)
    for oid, n in ids.items():
        if n > 1:
            E(oid, f"duplicate id ({n}x)")
    by_id = {o.get("id"): o for o in objs}

    approved = {x["id"] for x in t.get("assumptions", []) if x.get("approved_by_user")}
    all_assumptions = {x["id"] for x in t.get("assumptions", [])}
    for q in t.get("questions", []):
        if q.get("answer") in (None, ""):
            W(q.get("id"), f"open question: {q.get('text')}")

    geom_keys = Counter()
    for o in objs:
        oid = o.get("id", "?")
        typ = o.get("type")
        if typ not in TYPES:
            E(oid, f"unknown type '{typ}'")
            continue
        for ref in o.get("assumptions", []) or []:
            if ref not in all_assumptions:
                E(oid, f"assumption '{ref}' not defined")
            elif ref not in approved:
                W(oid, f"assumption '{ref}' not approved by user")
        conf = o.get("confidence")
        if not isinstance(conf, (int, float)):
            E(oid, "missing confidence")
        elif conf < a.min_confidence:
            W(oid, f"confidence {conf} < {a.min_confidence}")
        if not o.get("source"):
            E(oid, "missing source")

        if typ in ("column", "beam"):
            s, e = o.get("start_mm"), o.get("end_mm")
            if not (is_point(s) and is_point(e)):
                E(oid, "start_mm/end_mm must be [x,y,z]")
            else:
                if dist(s, e) < 1:
                    E(oid, "zero length")
                if typ == "column" and (abs(s[0] - e[0]) > 1 or abs(s[1] - e[1]) > 1):
                    W(oid, "column not vertical")
                geom_keys[(typ, tuple(round(v) for v in s), tuple(round(v) for v in e))] += 1
        if typ == "plate":
            c = o.get("contour_mm")
            if not (isinstance(c, list) and len(c) >= 3 and all(is_point(p) for p in c)):
                E(oid, "contour_mm needs 3+ [x,y,z] points")
        if typ in ("column", "beam", "plate"):
            for k in ("profile", "material"):
                if not o.get(k):
                    E(oid, f"missing {k}")
            if cat:
                prof = str(o.get("profile", "")).upper()
                if prof and not PARAMETRIC.match(prof) and prof not in cat.get("profile", set()):
                    E(oid, f"profile '{o.get('profile')}' not in catalog")
                mat = str(o.get("material", "")).upper()
                if mat and mat not in cat.get("material", set()):
                    E(oid, f"material '{o.get('material')}' not in catalog")
        if typ == "rebar":
            rb = o.get("rebar") or {}
            for k in ("grade", "size", "points_mm"):
                if not rb.get(k):
                    E(oid, f"rebar.{k} missing")
            if cat and rb.get("grade") and rb.get("size"):
                key = f"{rb['grade']} {rb['size']}".upper()
                if key not in cat.get("rebar", set()):
                    E(oid, f"rebar '{key}' not in catalog")
        if typ in ("rebar", "bolts", "weld", "assembly"):
            host = o.get("host_id")
            if not host:
                E(oid, "host_id missing (part this object attaches to)")
            elif host not in by_id:
                E(oid, f"host_id '{host}' not in objects")

    for (typ, s, e), n in geom_keys.items():
        if n > 1:
            W(typ, f"{n} objects with identical points {s}->{e}")

    counts = Counter((o.get("group"), o.get("type"), o.get("mark")) for o in objs)
    print("Counts (group, type, mark):")
    for (g, ty, m), n in sorted(counts.items(), key=lambda x: tuple(str(v) for v in x[0])):
        print(f"  {g} / {ty} / {m}: {n}")
    print(f"\nErrors: {len(errors)}")
    for x in errors:
        print("  E " + x)
    print(f"Warnings: {len(warnings)}")
    for x in warnings:
        print("  W " + x)
    sys.exit(1 if errors else 0)


if __name__ == "__main__":
    main()
