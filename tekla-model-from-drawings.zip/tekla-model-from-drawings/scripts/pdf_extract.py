#!/usr/bin/env python3
"""Extract text, vector geometry and page images from a vector PDF drawing.

Usage:
    python pdf_extract.py drawings.pdf --out extract/ [--dpi 150] [--pages 1,3-5]

Output per page N (1-based) in --out:
    pN_text.json   words: [{text, bbox:[x0,y0,x1,y1]}] in PDF points, y down
    pN_geom.json   lines: [[x0,y0,x1,y1], ...], rects: [[x0,y0,x1,y1], ...]
    pN.png         page image for visual reading
    summary.json   page sizes, scale texts found, counts

Requires: pip install pymupdf
1 PDF point = 0.3528 mm on paper. Model mm = paper mm * scale.
"""
import argparse
import json
import os
import re
import sys

try:
    import pymupdf as fitz
except ImportError:
    try:
        import fitz  # older PyMuPDF
    except ImportError:
        sys.exit("PyMuPDF missing: pip install pymupdf")

PT_TO_MM = 25.4 / 72.0
SCALE_RE = re.compile(r"\b1\s*:\s*(\d{1,4})\b")


def parse_pages(spec, count):
    if not spec:
        return list(range(count))
    out = []
    for part in spec.split(","):
        if "-" in part:
            a, b = part.split("-")
            out.extend(range(int(a) - 1, int(b)))
        else:
            out.append(int(part) - 1)
    return [p for p in out if 0 <= p < count]


def r(v):
    return round(v, 2)


def extract_page(page, idx, out, dpi):
    n = idx + 1
    words = [
        {"text": w[4], "bbox": [r(w[0]), r(w[1]), r(w[2]), r(w[3])]}
        for w in page.get_text("words")
    ]
    lines, rects = [], []
    for d in page.get_drawings():
        for item in d["items"]:
            kind = item[0]
            if kind == "l":
                p1, p2 = item[1], item[2]
                lines.append([r(p1.x), r(p1.y), r(p2.x), r(p2.y)])
            elif kind == "re":
                rc = item[1]
                rects.append([r(rc.x0), r(rc.y0), r(rc.x1), r(rc.y1)])
            elif kind == "qu":
                q = item[1]
                pts = [q.ul, q.ur, q.lr, q.ll, q.ul]
                for a, b in zip(pts, pts[1:]):
                    lines.append([r(a.x), r(a.y), r(b.x), r(b.y)])
    with open(os.path.join(out, f"p{n}_text.json"), "w", encoding="utf-8") as f:
        json.dump(words, f, ensure_ascii=False)
    with open(os.path.join(out, f"p{n}_geom.json"), "w", encoding="utf-8") as f:
        json.dump({"lines": lines, "rects": rects}, f)
    page.get_pixmap(dpi=dpi).save(os.path.join(out, f"p{n}.png"))

    full_text = page.get_text("text")
    scales = sorted({int(m) for m in SCALE_RE.findall(full_text)})
    return {
        "page": n,
        "size_pt": [r(page.rect.width), r(page.rect.height)],
        "size_mm": [r(page.rect.width * PT_TO_MM), r(page.rect.height * PT_TO_MM)],
        "rotation": page.rotation,
        "words": len(words),
        "lines": len(lines),
        "rects": len(rects),
        "scale_texts_found": [f"1:{s}" for s in scales],
        "vector": len(lines) + len(rects) > 0,
    }


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("pdf")
    ap.add_argument("--out", default="extract")
    ap.add_argument("--dpi", type=int, default=150)
    ap.add_argument("--pages", help="e.g. 1,3-5 (1-based)")
    a = ap.parse_args()

    os.makedirs(a.out, exist_ok=True)
    doc = fitz.open(a.pdf)
    pages = parse_pages(a.pages, doc.page_count)
    summary = {"file": os.path.abspath(a.pdf), "page_count": doc.page_count, "pages": []}
    for i in pages:
        info = extract_page(doc[i], i, a.out, a.dpi)
        summary["pages"].append(info)
        flag = "" if info["vector"] else "  WARNING: no vector geometry (scanned?)"
        print(f"page {info['page']}: {info['words']} words, {info['lines']} lines, "
              f"scales {info['scale_texts_found'] or '-'}{flag}")
    with open(os.path.join(a.out, "summary.json"), "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)
    print(f"written to {os.path.abspath(a.out)}")


if __name__ == "__main__":
    main()
