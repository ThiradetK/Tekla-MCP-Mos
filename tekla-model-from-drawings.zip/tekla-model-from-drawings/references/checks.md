# Post-build checks

Run after each group and once at the end. Report every failed item with object mark, GUID, expected value, model value.

## Per object (from MCP `verification` and `tekla_get_objects`)
- [ ] Exists, GUID recorded in `takeoff.json`
- [ ] Profile and material equal to takeoff
- [ ] Start/end (or base/top) within 1 mm of takeoff
- [ ] Length within 1 mm of takeoff
- [ ] Name / class as takeoff

## Per group (`tekla_find_objects` with name/profile filters)
- [ ] Count in model = count in takeoff
- [ ] No extra objects with the same name created in this session
- [ ] No two objects of the same type with identical start/end points (duplicates)

## Model-wide
- [ ] Column tops meet beam reference levels from the sections
- [ ] Beams end on column lines / grid lines as drawn
- [ ] Every concrete part that the drawings reinforce has rebar (when rebar was in scope)
- [ ] `tekla_quantity_summary`: total steel weight and concrete volume; compare with any totals given in the drawings. Difference > 2% → report.

## Report table
| Mark | Type | Takeoff count | Model count | Issues |
|---|---|---|---|---|
