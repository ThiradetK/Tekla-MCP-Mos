# Reading PDF structural drawings

## Sheet types and what to take from each
| Sheet | Take |
|---|---|
| General notes | concrete strength, rebar grades, steel grade, bolt grade, cover, units, codes |
| Grid / foundation plan | grid labels + spacings, footing marks (F1…), ground beam marks (GB1…), column marks at grid intersections |
| Floor / roof framing plan | beam marks (B1…), slab marks (S1…), beam lines between grids, offsets from grid, top-of-beam/slab level |
| Column schedule | per mark and floor: size, main bars, ties/stirrups |
| Beam schedule / sections | per mark: b×h, top/bottom bars, stirrups at support/mid-span |
| Footing schedule / details | size B×L×t, pile layout, bottom bars, top level |
| Steel member list | per mark: profile, material, length |
| Sections / elevations | levels (+0.000, +3.500 …), heights, slopes, member depth relations |
| Connection details | plates, bolts (number, size, pitch, edge), welds (type, size) |

## Marks
- Same mark = same properties. Collect positions from plans, properties from schedules.
- A mark on a plan with no schedule entry → question.
- Floor-dependent column sizes: the column schedule row per floor wins.

## Levels
- Written as metres relative to a datum (e.g. ±0.000 = FFL). Record the datum in `takeoff.json` → `levels`.
- Ask if the drawings show levels relative to different datums (e.g. GL vs FFL) without a stated offset.
- Concrete beam / slab level on plan is usually top of structure. Confirm from a section.

## Scale
1. Find the view scale text (e.g. `1:100`, `SCALE 1:50`). Each view on a sheet can have its own scale.
2. PDF units are points (1 pt = 1/72 in = 0.3528 mm on paper). Model mm = paper mm × scale.
3. Check: measure one dimension line in the extracted geometry and compare with its written value. Difference > 1% → do not use measured values for that view; ask.
4. Prefer written dimensions over measured ones. Use measured values only to place objects that have no written dimension, and flag them (confidence ≤ 0.7).

## Vector PDF extraction
- `pdf_extract.py` gives words with bbox, line segments, rectangles and page images.
- Text near a line (dimension text) belongs to the nearest dimension line parallel to the text.
- Grid bubbles: short text (A, B, 1, 2 …) inside a circle at line ends.
- Hatched areas and dense short lines are usually sections/hatching. Ignore them for member placement.

## When to stop and ask
- Two sheets disagree (size, level, count).
- A value is needed and not on any sheet.
- Scale check fails.
- Text unreadable or overlapping.
