# Tekla conventions for points and positions

All MCP coordinates are global mm. Grid origin (0,0,0) = first grid intersection unless the user says otherwise. Record the choice in `takeoff.json` → `grid.origin_mm`.

**Status:** the position defaults below must be confirmed once on the test model: build one object of each type, inspect it in Tekla, and record the result here. Until then, treat them as "to confirm" and show the user the preview.

## Columns (`tekla_create_column`)
- `base_mm` = grid intersection + plan offset, z = bottom level (top of footing or floor level).
- `top_mm` or `height_mm` = top level.
- Rectangular concrete column: `profile` "b*h" (parametric, e.g. "300*300"). Check orientation (b along X?) on the first column.
- Steel column: `rotation_offset_deg` sets web direction. Read web direction from the plan symbol.

## Beams (`tekla_create_beam`)
- `start_mm` / `end_mm` on the beam reference line: grid line + offset, z = level of the reference line.
- Reference line at **top** of beam (usual for concrete and steel framing). Then the beam must hang below the line. Setting to confirm: `position.depth` (expected "behind") with `rotation` "top".
- Concrete beam profile "b*h" (e.g. "250*500"). Confirm which value is width.
- Beam ends: column centre to column centre unless the drawing shows otherwise. Clash at column is normal for concrete; Tekla pour/cast-unit handling is out of scope.
- Steel beam on column face or centre: follow drawing; ask if not shown.

## Footings
- Pad footing modelled as a column-like part: base at bottom of footing, height = thickness, profile "B*L". Confirm with the user that this is acceptable (Tekla also has a dedicated footing object which the MCP does not expose).

## Slabs / plates (`tekla_create_plate`)
- `contour_mm` corner points at the slab reference level, in order around the outline.
- `profile` "PL<thickness>" (e.g. "PL150" for a 150 mm slab). Confirm thickness direction (up or down from contour) with `position.depth` on the first slab.

## Rebar (`tekla_create_rebar`)
- Needs `father_part_guid` from the built concrete part.
- `points_mm` = bar shape (centre line), already inside cover.
- Group: `start_mm`/`end_mm` = distribution direction, `spacing_mm` = target spacing.
- Grade + size from the schedule (e.g. "SD40" + "16"). Check catalog.

## Bolts (`tekla_create_bolts`)
- `first_point_mm` → `second_point_mm` defines the group axis.
- `array`: `dist_x_mm` spacings along the axis, `dist_y_mm` spacings across.

## Welds (`tekla_create_weld`)
- Main part = the part the weld belongs to in fabrication (usually the larger / column).
