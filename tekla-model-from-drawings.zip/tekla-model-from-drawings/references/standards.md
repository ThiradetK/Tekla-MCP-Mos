# Company standards (to be filled)

Status: **no company standard provided yet.**
Rule: an empty item is not a default. If a job needs it, ask the user and record the answer in `takeoff.json` → `assumptions`. When the user confirms a value as a standing rule, add it here.

Catalog names must exist in the SE_Asia environment. Check with `tekla_list_catalog`.

## Materials
| Use | Material name in Tekla | Note |
|---|---|---|
| Structural steel | | |
| Plates | | |
| Concrete (columns) | | |
| Concrete (beams/slabs) | | |
| Concrete (footings) | | |
| Lean concrete | | |

## Rebar
| Size range | Grade | Note |
|---|---|---|
| Round bars | | |
| Deformed bars | | |
| Concrete cover: footing / column / beam / slab (mm) | | |

## Bolts
| Use | Standard | Size | Washer / nut |
|---|---|---|---|
| Main connections | | | |
| Anchor bolts | | | |

## Classes (colour) per member type
| Member | Class |
|---|---|
| Steel column | |
| Steel beam | |
| Plate | |
| Concrete footing | |
| Concrete column | |
| Concrete beam | |
| Slab | |

## Names
| Member | Part name |
|---|---|
| | |

## Numbering prefixes (part / assembly)
| Member | Part prefix | Assembly prefix |
|---|---|---|
| | | |

## UDAs required
| UDA name | Value source |
|---|---|
| | |
