# MCP recipes

All write tools: call `mode:"preview"` → check → call again with identical arguments + `mode:"apply"` + `confirm_token`. Tokens are single use and expire.

## 0. Session
```
tekla_status                       → model name, environment, read_only
tekla_save_model {mode:"preview", comment:"before takeoff build"} → apply
```

## 1. Catalog check → catalog.json
For each distinct name in the takeoff:
```
tekla_list_catalog {kind:"profile",  filter:"WF400X200*"}
tekla_list_catalog {kind:"material", filter:"SS400"}
tekla_list_catalog {kind:"rebar",    filter:"SD40*"}
tekla_list_catalog {kind:"bolt",     filter:"*"}
```
Parametric profiles ("300*600", "PL20") are not catalog entries; the create tool checks them at preview.
Save the found names as:
```json
{"profile":["WF400X200X8X13"], "material":["SS400","C30"], "rebar":["SD40 16"], "bolt":["8.8XOX 20"]}
```

## 2. Grid
```json
tekla_create_grid {
  "coordinate_x":"0 3*6000", "label_x":"A B C D",
  "coordinate_y":"0 2*5000", "label_y":"1 2 3",
  "coordinate_z":"0 3500 7000", "label_z":"+0.000 +3.500 +7.000",
  "mode":"preview"}
```

## 3. Column
```json
tekla_create_column {"base_mm":[0,0,0], "top_mm":[0,0,3500],
  "profile":"300*300", "material":"C30", "name":"C1", "class":"",
  "mode":"preview"}
```

## 4. Beam
```json
tekla_create_beam {"start_mm":[0,0,3500], "end_mm":[6000,0,3500],
  "profile":"250*500", "material":"C30", "name":"B1",
  "position":{"rotation":"top","depth":"behind","plane":"middle"},
  "mode":"preview"}
```

## 5. Slab / plate
```json
tekla_create_plate {"contour_mm":[[0,0,3500],[6000,0,3500],[6000,5000,3500],[0,5000,3500]],
  "profile":"PL120", "material":"C30", "name":"S1", "mode":"preview"}
```

## 6. Rebar group
```json
tekla_create_rebar {"kind":"group", "father_part_guid":"<beam guid>",
  "points_mm":[[...],[...]], "start_mm":[...], "end_mm":[...], "spacing_mm":150,
  "grade":"SD40", "size":"12", "mode":"preview"}
```

## 7. Bolts / weld / assembly
```
tekla_create_bolts    {kind:"array", part_to_bolt_to_guid, part_to_be_bolted_guid, first_point_mm, second_point_mm, bolt_standard, bolt_size_mm, dist_x_mm, dist_y_mm, mode}
tekla_create_weld     {main_part_guid, secondary_part_guid, size_above_mm, type_above:"fillet", mode}
tekla_create_assembly {main_part_guid, secondary_part_guids, name, mode}
```

## 8. Verify
```
tekla_find_objects {types:["part"], name:"B1", include_quantities:true, limit:500}
tekla_get_objects  {guids:[...]}
tekla_quantity_summary
```

Values in the examples are illustrations of argument shape only. Real values come from the approved takeoff.
