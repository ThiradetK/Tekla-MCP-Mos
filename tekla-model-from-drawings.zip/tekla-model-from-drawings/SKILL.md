---
name: tekla-model-from-drawings
description: Build a Tekla Structures model (steel and/or reinforced concrete) from vector PDF structural drawings using the tekla_* MCP tools. Use when the user hands over PDF drawings or a requirement and asks to model it in Tekla, ขึ้นโมเดล Tekla จากแบบ, ถอดแบบลง Tekla.
---

# Tekla model from PDF drawings

Pipeline: PDF vector drawings → `takeoff.json` → user approval → Tekla via `tekla_*` MCP tools → verification report.

`takeoff.json` is the single source of truth between drawing and model. Never call a create tool for an object that is not in the approved takeoff.

## Hard rules

1. **No guessing.** A value missing or unreadable in the drawings is a question for the user, not a default. Record every assumption the user approves in `takeoff.json` → `assumptions`.
2. **No apply without approval.** The MCP tools need `mode:"preview"` then `mode:"apply"` + `confirm_token`. Apply only objects inside a group the user approved in this conversation.
3. **Catalog first.** Check every profile, material, rebar grade/size and bolt against the catalog with `tekla_list_catalog` before the checkpoint. Environment is SE_Asia.
4. **Model copy only.** Check with `tekla_status` that the open model is the test copy the user named. If unsure, ask.
5. **Save before building.** Run `tekla_save_model` (preview → apply) before the first group.
6. **Units.** The MCP tools use global mm. Convert every drawing value to mm. Levels in m (e.g. +3.500) → mm (3500).
7. **Company standards are not defined yet.** Read `references/standards.md`. Ask the user for any blank item the job needs.

## Steps

### 1. Intake
- `tekla_status` → confirm connection, model name, read-only flag.
- List PDF pages. For each page, classify: grid/foundation plan, floor framing plan, roof plan, section, elevation, column/beam/footing schedule, rebar detail, connection detail, general notes.
- Read general notes first: concrete strength, rebar grades, steel grade, bolt grade, cover, units.

### 2. Extract
- Run `python scripts/pdf_extract.py <file.pdf> --out extract/` for text with positions, vector lines and page images.
- Look at the page images to understand layout. Use the extracted text/geometry for numbers.
- Set the drawing scale per view (see `references/reading-drawings.md` §Scale). Check it against at least one written dimension. Mismatch > 1% → stop and ask.

### 3. Interpret → takeoff.json
- Build grids and levels first. They are the frame for all coordinates.
- Match every member mark in plans (C1, B1, GB1, F1, S1 …) to its schedule/section for profile, size, material and rebar.
- Write `takeoff.json` following `scripts/takeoff_schema.json`. Every object carries: `source` (sheet + view), `confidence` (0–1), `assumptions`.
- Read `references/tekla-conventions.md` for start/end points and position settings.

### 4. Validate
- Run `python scripts/validate_takeoff.py takeoff.json --catalog catalog.json`.
  - Build `catalog.json` from `tekla_list_catalog` results for the names in use (see `references/mcp-recipes.md`).
- Fix errors. Turn every warning into a question or an approved assumption.

### 5. Checkpoint — stop and wait
Present to the user:
- Grid and level table.
- Object count per group and type (e.g. Columns C1 ×12, Beams B1 ×18).
- Profile/material list with catalog status.
- Open questions, and objects with confidence < 0.8.
- Build order and number of MCP calls.

Ask for approval **per group** or for all groups. Do not continue without it.

### 6. Build
Order: grid → footings → columns → beams → slabs/plates → rebar → bolts/welds → assemblies.
For each approved group:
1. Call `preview` for each object, check the planned change matches the takeoff.
2. Call `apply` with the token for each object.
3. Write the returned GUID into `takeoff.json` (`tekla_guid`). Later steps (rebar, bolts, welds) need these GUIDs.
4. Any error or verification mismatch → stop the group, report, ask.

### 7. Verify
Follow `references/checks.md`. Use `tekla_find_objects` (with `include_quantities`) and `tekla_get_objects`. Compare model against takeoff: count, coordinates, length, profile, material, weight.

### 8. Report
- What was built (per group, counts).
- Assumptions used.
- Mismatches and items left for the engineer.
- Files: `takeoff.json`, `extract/`, verification table.

## References
- `references/reading-drawings.md` — sheet types, marks, schedules, scale, levels in Thai structural drawings
- `references/tekla-conventions.md` — points and position settings per member type
- `references/mcp-recipes.md` — tool call order and example arguments
- `references/checks.md` — post-build checklist
- `references/standards.md` — company standards (to be filled by the user)
